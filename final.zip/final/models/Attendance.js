const mongoose = require('mongoose');

const AttendanceSchema = new mongoose.Schema({
    employeeId: { type: String, required: true },
    name: { type: String, required: true },
    date: { type: Date, default: Date.now },
    location: { type: String },
    time: { type: String, required: true },
    type: { type: String, enum: ['Check-In', 'Check-Out', 'Manual'], required: true },
    reason: { type: String, default: null },
});

module.exports = mongoose.model('Attendance', AttendanceSchema);
