const loginForm = document.getElementById('loginForm');
const errorMessage = document.getElementById('errorMessage');

loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const employeeId = document.getElementById('employeeId').value;
    const password = document.getElementById('password').value;

    try {
        const res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ employeeId, password }),
        });

        const data = await res.json();
        if (res.ok) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('username', data.employee.name);
            window.location.href = 'dashboard.html';
        } else {
            errorMessage.textContent = data.msg;
        }
    } catch (error) {
        errorMessage.textContent = 'Server Error';
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const logoutBtn = document.getElementById('logoutBtn');
    const username = localStorage.getItem('username');
    if (username) document.getElementById('username').textContent = username;

    logoutBtn?.addEventListener('click', () => {
        localStorage.clear();
        window.location.href = 'login.html';
    });
});
