const express = require('express');
const router = express.Router();
const leave = require('../models/leave');

// Apply Leave
router.post('/apply', async (req, res) => {
    const { employeeId, name, fromDate, toDate, reason } = req.body;

    try {
        const leave = new Leave({ employeeId, name, fromDate, toDate, reason });
        await leave.save();
        res.status(201).json({ msg: 'Leave Applied Successfully', leave });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
