const express = require('express');
const router = express.Router();
const Attendance = require('../models/Attendance');

// Check-In/Check-Out with Location Validation
router.post('/mark', async (req, res) => {
    const { employeeId, name, latitude, longitude, type, reason } = req.body;
    const officeLatitude = 13.159645;
    const officeLongitude = 77.636229;

    try {
        const distance = Math.sqrt((latitude - officeLatitude) ** 2 + (longitude - officeLongitude) ** 2);
        if (distance > 0.005 && !reason) {
            return res.status(400).json({ msg: 'You are not within the office radius. Provide a reason.' });
        }

        const attendance = new Attendance({
            employeeId,
            name,
            location: `Lat: ${latitude}, Long: ${longitude}`,
            time: new Date().toLocaleTimeString(),
            type: reason ? 'Manual' : type,
            reason,
        });

        await attendance.save();
        res.status(200).json({ msg: 'Attendance Marked Successfully', attendance });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
