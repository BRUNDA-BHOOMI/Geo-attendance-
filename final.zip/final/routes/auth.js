const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Employee = require('../models/Employee');

// Register Employee
router.post('/register', async (req, res) => {
    const { name, employeeId, department, email, password } = req.body;

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const employee = new Employee({ name, employeeId, department, email, password: hashedPassword });
        await employee.save();

        res.status(201).json({ msg: 'Employee Registered Successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Login Employee
router.post('/login', async (req, res) => {
    const { employeeId, password } = req.body;

    try {
        const employee = await Employee.findOne({ employeeId });
        if (!employee) return res.status(400).json({ msg: 'Employee Not Found' });

        const isMatch = await bcrypt.compare(password, employee.password);
        if (!isMatch) return res.status(400).json({ msg: 'Invalid Credentials' });

        const token = jwt.sign({ employeeId: employee.employeeId, name: employee.name }, 'secretKey', {
            expiresIn: '1h',
        });

        res.status(200).json({ token, employee });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
