const mongoose = require('mongoose');

const uri = 'mongodb://localhost:27017/geoattendance';  // Replace with your MongoDB connection URI if needed

const connectDB = async () => {
    try {
        await mongoose.connect(uri, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log('MongoDB connected successfully!');
    } catch (err) {
        console.error('Error connecting to MongoDB:', err.message);
        process.exit(1);  // Exit the app if connection fails
    }
};

module.exports = connectDB;  // Export the connectDB function
